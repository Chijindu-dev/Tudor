const s="/assets/c3-Ik-lKFY8.png";export{s as d};
